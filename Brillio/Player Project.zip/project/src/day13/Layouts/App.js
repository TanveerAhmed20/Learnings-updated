import React from 'react'
import Layout from './Layout';
const App = () => {
  return (
    <Layout></Layout>
  )
}

export default App