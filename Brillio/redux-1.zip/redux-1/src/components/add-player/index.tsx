import { Card, CardHeader, CardBody, Form, Button } from "reactstrap";
import { connect } from "react-redux";
import { Player, PlayerActionDispatch } from "../../types";
import { addPlayer as addPlayerAction } from "../../store/actions/player.actions";

interface AddPlayerProps {
  addPlayerProp: (payload: Player) => void;
}

const player: Player =  {
	name: "Pulkit",
	image: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170658/rohit-sharma.jpg",
	country: "IND",
	type: "Batsman"
  }

// const player: Player =  {
//   name: "Virat",
//   image: "https://p.imgci.com/db/PICTURES/CMS/289000/289002.1.jpg",
//   country: "IND",
//   type: "Batsman"
// }

// const player: Player = {
//   name: "Dhoni",
//   image: "https://p.imgci.com/db/PICTURES/CMS/302400/302402.jpg",
//   country: "IND",
//   type: "Wicket Keeper",
// };

function AddPlayer({ addPlayerProp }: AddPlayerProps) {

  const handleAddPlayer = (evt: React.FormEvent<HTMLFormElement>) => {
    evt.preventDefault();
    addPlayerProp(player);
  };

  return (
    <Card>
      <CardHeader>
        <h4>Add My Player</h4>
      </CardHeader>
      <CardBody>
        <Form onSubmit={handleAddPlayer}>
          <div className="d-flex justify-content-center">
            <Button color="danger" type="submit">
              Add Player
            </Button>
          </div>
        </Form>
      </CardBody>
    </Card>
  );
}

// dispatch triggers an event to our reducer
// all our actions (ADD, UPDATE, DELETE) are sent as functions to 
// Our AddPlayer Component (line 31) as props
const mapDispatchToProps = (dispatch: PlayerActionDispatch) => {
  return {
    // dispatch(  {type: "ADD_PLAYER", payloadWithID}    )
    // dispatch function always must contain only type and payload
    addPlayerProp: (player: Player) => dispatch( addPlayerAction(player) ),
  };
};

 const mapStateToProps = () => ({});

// both mapStateToProps and mapDispatchToProps are executed when connect
// method is called. When props are ready, the component AddPlayer is rendered.
export default connect(mapStateToProps, mapDispatchToProps)   (AddPlayer);
