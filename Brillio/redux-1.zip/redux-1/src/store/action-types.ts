const ADD_PLAYER = "ADD_PLAYER";

export {
    ADD_PLAYER
}
