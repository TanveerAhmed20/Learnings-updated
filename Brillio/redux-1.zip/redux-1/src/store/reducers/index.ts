import { combineReducers } from "redux";
import players from "./player.reducer";


export default combineReducers({
    players
});
